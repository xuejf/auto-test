# -*- coding: utf-8 -*-
from .HTMLTestRunner_PY3 import HTMLTestRunner


__author__ = """Ordanis Sanchez Suero"""
__email__ = 'ordanisanchez@gmail.com'
__version__ = '1.1.2'